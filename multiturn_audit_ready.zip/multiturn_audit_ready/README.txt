多轮评测集审核目录

使用方法：
1. 打开 multiturn_audit.html。
2. 点击“选择推荐 JSON”。
3. 选择同目录中的 multiturn_eval_set_approved.json。
4. 逐条审核；备注、勾选项和“通过/需修改”状态会自动保存在浏览器本地。

说明：
- 这是最终审核版，共 850 条用例、17 个维度。
- 不要选择 draft_*.json 或 review_*.json，它们是过程文件。
- 如需备份审核结果，点击页面右上角“导出审核记录”。
